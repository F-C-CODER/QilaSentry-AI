import express from "express";
import path from "path";
import fs from "fs/promises";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const DB_FILE = path.join(process.cwd(), "qr_database.json");

// Helper to load QR database
async function loadDb() {
  let data: any = {};
  try {
    const content = await fs.readFile(DB_FILE, "utf-8");
    data = JSON.parse(content);
  } catch (err) {
    data = {};
  }

  // Seed Static Red Fort QR entries
  if (!data["static-1-history-redfort"]) {
    data["static-1-history-redfort"] = {
      id: "static-1-history-redfort",
      title: "History of Red Fort (Lal Qila)",
      text: "The Red Fort (Lal Qila) was commissioned by the Mughal Emperor Shah Jahan in 1638 when he decided to shift his capital from Agra to Delhi. Built of majestic red sandstone, this fortress served as the seat of the Mughal Empire for over 200 years. It was designated a UNESCO World Heritage Site in 2007 and stands today as a grand symbol of India's sovereign history.",
      image: "",
      createdAt: "2026-01-01T00:00:00.000Z"
    };
  }
  if (!data["static-2-speciality-redfort"]) {
    data["static-2-speciality-redfort"] = {
      id: "static-2-speciality-redfort",
      title: "Speciality of Red Fort (Architecture)",
      text: "This masterpiece represents the zenith of Mughal architectural creativity, seamlessly blending Persian, Timurid, and Hindu structural traditions. Famous features include the monumental Lahori Gate, the exquisite white marble palace Diwan-i-Khas (where the Peacock Throne stood), and the beautifully geometric Hayat Bakhsh Bagh gardens.",
      image: "",
      createdAt: "2026-01-02T00:00:00.000Z"
    };
  }
  return data;
}

// Helper to save QR database
async function saveDb(data: any) {
  await fs.writeFile(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Increase payload limits to support base64 images uploaded by users
  app.use(express.json({ limit: "15mb" }));
  app.use(express.urlencoded({ limit: "15mb", extended: true }));

  // Initialize Gemini Client with designated user-agent header
  let ai: GoogleGenAI | null = null;
  if (process.env.GEMINI_API_KEY) {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });
  }

  // --- API Routes ---

  // Chat with Red Fort Expert (Gemini)
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history, language } = req.body;
      if (!message) {
        return res.status(400).json({ error: "Message is required." });
      }

      if (!ai) {
        return res.status(503).json({
          error: "Gemini API Key is not configured on the server. Please add GEMINI_API_KEY to your Secrets."
        });
      }

      // Convert history to contents form if provided
      let contentsList: any[] = [];
      if (history && Array.isArray(history)) {
        contentsList = history.map((chat: { role: string; content: string }) => ({
          role: chat.role === "user" ? "user" : "model",
          parts: [{ text: chat.content }]
        }));
      }
      contentsList.push({ role: "user", parts: [{ text: message }] });

      const langText = language === "hi" ? "pure HINDI script (हिन्दी)" : "ENGLISH";
      const systemInstruction = `You are a strict, historically precise AI guide for the Red Fort (Lal Qila) in Delhi, India.

CRITICAL DIRECTIVES:
1. Language requirement: You MUST write your response entirely in ${langText}.
2. Response length limit: Do not write paragraphs. Your response MUST be extremely brief - maximum of 1 or 2 short sentences. Cut off all fluff and preamble. Focus only on the requested direct historical facts.
3. Strict topic boundary: You are ONLY authorized to answer questions about the Red Fort (Lal Qila). This includes its builder (Shah Jahan), gates (Lahori Gate, Delhi Gate), halls (Diwan-i-Aam, Diwan-i-Khas), gardens, museums, and traveler info.
4. If the user's message is off-topic (anything that is NOT about the Red Fort, e.g., general mathematics, other global monuments, cooking, general coding, random banter), you MUST reject it immediately and reply exactly with this short statement:
   - In English: "I am sorry, but as the Red Fort AI Hub Scribe, I am only authorized to answer questions regarding the history, architecture, and visitor details of the Red Fort. Please ask a question related to Lal Qila."
   - In Hindi: "मुझे खेद है, लेकिन लाल किला एआई हब लेखक के रूप में, मैं केवल लाल किले के इतिहास, वास्तुकला और आगंतुकों के विवरण के संबंध में प्रश्नों के उत्तर देने के लिए अधिकृत हूं। कृपया लाल किले से संबंधित प्रश्न पूछें।"`;

      // Call Gemini API
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contentsList,
        config: {
          systemInstruction,
        },
      });

      const responseText = response.text || "I was unable to retrieve a response. Please try asking again.";
      res.json({ text: responseText.trim() });
    } catch (err: any) {
      console.error("Gemini Chatbot Error:", err);
      
      let errorMsg = err.message || "Failed to communicate with AI model.";
      const errorStr = JSON.stringify(err).toLowerCase();
      
      if (
        errorMsg.toLowerCase().includes("quota") ||
        errorMsg.toLowerCase().includes("429") ||
        errorMsg.toLowerCase().includes("limit") ||
        errorMsg.toLowerCase().includes("exhausted") ||
        errorStr.includes("quota") ||
        errorStr.includes("429") ||
        errorStr.includes("exhausted") ||
        err.status === 429 ||
        err.statusCode === 429
      ) {
        errorMsg = (req.body?.language === "hi")
          ? "⚠️ प्रिय यात्री, दैनिक कोटा सीमा समाप्त हो गई है! कृपया 30 सेकंड बाद पुनः प्रयास करें या AI Studio के Settings menu में अपनी स्वयं की GEMINI_API_KEY कॉन्फ़िगर करें।"
          : "⚠️ Daily Gemini API quota limit exceeded! Please wait 30 seconds and try again, or configure your own GEMINI_API_KEY in the AI Studio Settings menu to bypass limits.";
      }
      
      res.status(500).json({ error: errorMsg });
    }
  });

  // Create QR entry
  app.post("/api/qr", async (req, res) => {
    try {
      const { text, image, title } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Text/Information is required." });
      }

      const db = await loadDb();
      const id = Date.now().toString(36) + Math.random().toString(36).substring(2, 6);

      db[id] = {
        id,
        title: title || "Red Fort Memory",
        text,
        image: image || "", // base64 string
        createdAt: new Date().toISOString(),
      };

      await saveDb(db);
      res.json({ success: true, id });
    } catch (err: any) {
      console.error("Save QR Error:", err);
      res.status(500).json({ error: "Failed to store QR data on the server." });
    }
  });

  // Get QR details
  app.get("/api/qr/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const db = await loadDb();
      const item = db[id];

      if (!item) {
        return res.status(404).json({ error: "Information matching this QR code was not found or was deleted." });
      }

      res.json({ success: true, item });
    } catch (err: any) {
      console.error("Get QR Error:", err);
      res.status(500).json({ error: "Failed to read QR information from the server." });
    }
  });

  // Get all QRs (for list to view and delete)
  app.get("/api/qrs", async (req, res) => {
    try {
      const db = await loadDb();
      const list = Object.values(db).sort(
        (a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      res.json({ success: true, list });
    } catch (err: any) {
      console.error("Get All QRs Error:", err);
      res.status(500).json({ error: "Failed to read QR codes list." });
    }
  });

  // Delete QR
  app.delete("/api/qr/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const db = await loadDb();

      if (!db[id]) {
        return res.status(404).json({ error: "QR code not found." });
      }

      delete db[id];
      await saveDb(db);

      res.json({ success: true });
    } catch (err: any) {
      console.error("Delete QR Error:", err);
      res.status(500).json({ error: "Failed to delete QR from server." });
    }
  });

  // Serve static files / Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

startServer();
