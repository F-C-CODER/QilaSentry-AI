/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ChatMessage {
  id: string;
  role: "user" | "bot";
  text: string;
  timestamp: string;
}

export interface QRItem {
  id: string;
  title: string;
  text: string;
  image?: string; // Base64 representation of uploaded image
  createdAt: string;
}
