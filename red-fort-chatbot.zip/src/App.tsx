import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Compass, Award } from "lucide-react";
import Navbar from "./components/Navbar";
import HomeView from "./components/HomeView";
import RED_FORT_IMAGE from "./assets/images/red_fort_sunset_1780721482359.png";

export default function App() {
  const [currentTab, setCurrentTab] = useState<"home" | "exit">("home");

  return (
    <div 
      className="min-h-screen flex flex-col selection:bg-amber-500/30 selection:text-amber-200 relative overflow-x-hidden"
      style={{
        backgroundImage: `linear-gradient(to bottom, rgba(3, 15, 30, 0.25), rgba(15, 8, 8, 0.4)), url(${RED_FORT_IMAGE})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed"
      }}
    >
      
      {/* Persisted Header Navigation Bar */}
      <Navbar currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Subview Section router */}
      <main className="flex-1 flex flex-col py-6 relative z-10">
        <AnimatePresence mode="wait">
          {currentTab === "home" && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
              className="flex flex-col flex-1"
            >
              <HomeView />
            </motion.div>
          )}

          {currentTab === "exit" && (
            <motion.div
              key="exit"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              className="max-w-md mx-auto my-auto p-8 text-center bg-sky-950/40 border border-sky-500/20 rounded-2xl shadow-2xl font-serif backdrop-blur-md"
            >
              <Award className="h-14 w-14 text-amber-450 mx-auto mb-4 animate-bounce" />
              <h2 className="text-2xl font-serif font-bold text-amber-400 tracking-wider mb-2">
                THANK YOU FOR VISITING
              </h2>
              <p className="text-sky-100 text-base leading-relaxed mb-6 font-serif">
                The history, monuments, and stories of Lal Qila endure. We hope this companion AI guide enriched your royal heritage exploration of Delhi.
              </p>
              
              <div className="border-t border-sky-900/60 pt-5 flex flex-col space-y-3">
                <button
                  onClick={() => setCurrentTab("home")}
                  className="w-full py-2.5 font-serif font-bold text-sm text-slate-900 bg-gradient-to-r from-sky-400 via-sky-300 to-sky-500 rounded-lg hover:from-sky-300 hover:to-sky-400 transition-all flex items-center justify-center space-x-1 shadow-md cursor-pointer"
                >
                  <Compass className="h-4 w-4" />
                  <span>Enter Lal Qila Scribe Portal</span>
                </button>
                
                <p className="text-[11px] text-sky-450 tracking-widest font-semibold uppercase">
                  Red Fort AI Hub
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Persistent mini copyright line */}
      <footer className="w-full text-center py-4 bg-slate-950/40 text-sky-400/50 text-[11px] font-serif border-t border-sky-950/20 mt-auto print:hidden">
        <span>© 2026 RED FORT AI HUB • UNESCO HERITAGE COMPANION GUIDE</span>
      </footer>
    </div>
  );
}
