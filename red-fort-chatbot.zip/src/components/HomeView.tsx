import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Volume2, VolumeX, Mic, Send, HelpCircle, RefreshCw, Compass } from "lucide-react";
import { ChatMessage } from "../types";
import SpeechIndicator from "./SpeechIndicator";
import RED_FORT_IMAGE from "../assets/images/red_fort_sunset_1780721482359.png";

export default function HomeView() {
  const [inputText, setInputText] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [errMessage, setErrMessage] = useState("");
  
  // Selected output language state: "en" for English, "hi" for Hindi
  const [writeLanguage, setWriteLanguage] = useState<"en" | "hi">("en");

  // Voice Autostart toggle state (Default to ON, persisted back in localStorage)
  const [isVoiceAutostart, setIsVoiceAutostart] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("redfort_voice_autostart");
      return saved !== "false"; // default true
    }
    return true;
  });

  const toggleVoiceAutostart = () => {
    setIsVoiceAutostart((prev) => {
      const newVal = !prev;
      if (typeof window !== "undefined") {
        localStorage.setItem("redfort_voice_autostart", String(newVal));
      }
      return newVal;
    });
  };

  // Speech synthesis states
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const recognitionRef = useRef<any>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize Speech Synthesis
  useEffect(() => {
    if (typeof window !== "undefined") {
      synthRef.current = window.speechSynthesis;
    }
    return () => {
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, []);

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Cancel speech synthesis if the chosen writeLanguage preference changes
  useEffect(() => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setSpeakingMsgId(null);
    }
  }, [writeLanguage]);

  // Handle Search Input Submission
  const handleQuery = async (textToSend: string) => {
    const text = textToSend.trim();
    if (!text) return;

    // Direct stop of voice output on new search
    if (synthRef.current) {
      synthRef.current.cancel();
      setSpeakingMsgId(null);
    }

    setErrMessage("");
    const userMsg: ChatMessage = {
      id: "usr-" + Date.now().toString(36),
      role: "user",
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    // After every query, we reset the message view to ONLY focus on the current lookup
    setMessages([userMsg]);
    setInputText("");
    setIsLoading(true);

    try {
      // Clear previous context history context entirely to obey the 'after every search list clear' requirement
      const historyContext: any[] = [];

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          message: text, 
          history: historyContext,
          language: writeLanguage 
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to contact Red Fort bot");
      }

      const botMsg: ChatMessage = {
        id: "bot-" + Date.now().toString(36),
        role: "bot",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, botMsg]);

      // Trigger narration directly based on elected Language preference instantly if enabled!
      if (isVoiceAutostart) {
        speakText(botMsg.id, data.text, writeLanguage);
      }

    } catch (err: any) {
      console.error(err);
      setErrMessage(err.message || "Apologies, I cannot answer right now. Check server keys.");
    } finally {
      setIsLoading(false);
    }
  };

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleQuery(inputText);
  };

  // Speak-to-Search (Speech Recognition) API
  const startVoiceSearch = () => {
    if (typeof window === "undefined") return;

    // Toggle off if already listening
    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {
          console.error("Error aborting recognition:", e);
        }
      }
      setIsListening(false);
      return;
    }

    // Turn on listening immediately so button turns red instantly
    setIsListening(true);

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Voice / Speech Recognition is not natively supported in this browser. Please try Chrome, Edge, or Safari. You can still type your questions or use the buttons below anytime!");
      setIsListening(false);
      return;
    }

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }

      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.continuous = false;
      // Set to Indian English or Hindi for better native speech alignment
      recognition.lang = writeLanguage === "hi" ? "hi-IN" : "en-IN"; 
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        // Automatically search upon complete mic voice entry
        if (transcript.trim()) {
          handleQuery(transcript);
        }
      };

      recognition.onerror = (e: any) => {
        console.error("Speech Recognition Error:", e);
        setIsListening(false);
        if (e.error === "not-allowed") {
          alert("Microphone access is denied or blocked. Please click 'Open in a new tab' in AI Studio (top-right corner of the preview) to grant microphone access securely as Chrome block inside iframes.");
        } else if (e.error === "network") {
          alert("Network error during voice typing. Please check your connection.");
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.error("Voice instantiation failed:", err);
      setIsListening(false);
    }
  };

  // Parameterized text-to-speech option with low pace and Indian voice options
  const speakText = (msgId: string, textToSpeak: string, speakLang: "en" | "hi") => {
    if (!synthRef.current) return;

    const trackingKey = `${msgId}-${speakLang}`;

    // If currently reading this message and language, stop it
    if (speakingMsgId === trackingKey) {
      try {
        synthRef.current.cancel();
      } catch (e) {}
      setSpeakingMsgId(null);
      return;
    }

    try {
      // Stop all previous speech
      synthRef.current.cancel();
    } catch (e) {
      console.warn("speech cancel error", e);
    }

    // A small timeout ensures the browser's native audio engine clears fully
    setTimeout(() => {
      try {
        if (!synthRef.current) return;

        // Setup speech utterance config
        const cleanText = textToSpeak.replace(/[*#_`~]/g, ""); // strip markdown
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utteranceRef.current = utterance; // keep reference in ref to prevent Chrome garbage collection bug

        // Pace setting: slow and comfortable pace as requested
        utterance.rate = 0.76;

        const voices = synthRef.current.getVoices();

        if (speakLang === "hi") {
          utterance.lang = "hi-IN";
          const hindiVoice = voices.find((v) => v.lang.includes("hi-IN") || v.lang.includes("hi"));
          if (hindiVoice) {
            utterance.voice = hindiVoice;
          }
        } else {
          utterance.lang = "en-IN";
          // Fetch English with Indian pronunciation accent or fallback
          const indianVoice = voices.find((v) => v.lang.includes("en-IN") || v.lang.includes("en-GB"));
          if (indianVoice) {
            utterance.voice = indianVoice;
          }
        }

        utterance.onend = () => {
          setSpeakingMsgId(null);
        };

        utterance.onerror = (evt) => {
          console.warn("SpeechSynthesisUtterance error:", evt);
          setSpeakingMsgId(null);
        };

        setSpeakingMsgId(trackingKey);
        synthRef.current.speak(utterance);

        // Extra guard: resume if paused unexpectedly
        if (synthRef.current.paused) {
          synthRef.current.resume();
        }
      } catch (err) {
        console.error("Speech trigger failed:", err);
        setSpeakingMsgId(null);
      }
    }, 100);
  };

  // Starter query accelerators (Bilingual translation fallback)
  const quickSearches = writeLanguage === "hi" ? [
    "लाल किला किसने बनवाया?",
    "लाहोरी गेट के बारे में बताएं",
    "मोती मस्जिद कहाँ स्थित है?",
    "लाइट एंड साउंड शो का समय",
  ] : [
    "Who built the Red Fort?",
    "Tell me about Lahori Gate",
    "Where is Moti Masjid located?",
    "Sound and Light show timings",
  ];

  return (
    <div id="home-container" className="flex flex-col flex-1 max-w-4xl mx-auto px-4 py-3 relative min-h-[calc(100vh-6em)]">
      
      {/* PREFERENCE CONTROLS PANEL (LANGUAGE & AUTO-SPEAK) */}
      <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-2 mb-3 w-full">
        {/* Voice Auto-start Toggle */}
        <div className="bg-sky-950/60 border border-sky-500/20 rounded-full p-1.5 flex items-center justify-between sm:justify-start space-x-1.5 backdrop-blur-sm">
          <span className="text-xs text-sky-300 px-2 font-serif flex items-center space-x-1.5 select-none">
            <span>📢</span>
            <span className="font-semibold">Auto-Speak Answer:</span>
          </span>
          <button
            type="button"
            onClick={toggleVoiceAutostart}
            className={`px-3.5 py-1 text-xs font-bold rounded-full transition-all cursor-pointer flex items-center space-x-1.5 shadow-sm active:scale-95 ${
              isVoiceAutostart 
                ? "bg-amber-450 hover:bg-amber-400 text-slate-950" 
                : "bg-slate-900/90 text-slate-400 hover:text-slate-300 border border-slate-700/60"
            }`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${isVoiceAutostart ? "bg-slate-950 animate-ping" : "bg-slate-500"}`}></span>
            <span>{isVoiceAutostart ? "ON" : "OFF"}</span>
          </button>
        </div>

        {/* Language selector choice */}
        <div className="bg-sky-950/60 border border-sky-500/20 rounded-full p-1.5 flex items-center justify-between sm:justify-start space-x-1 backdrop-blur-sm">
          <span className="text-xs text-sky-300 px-2 font-serif select-none font-semibold">Language preference:</span>
          <div className="flex space-x-0.5">
            <button
              type="button"
              onClick={() => setWriteLanguage("en")}
              className={`px-3 py-1 text-xs font-bold rounded-full transition-all cursor-pointer active:scale-95 ${
                writeLanguage === "en" ? "bg-sky-500 text-slate-950" : "text-sky-300 hover:text-sky-200"
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setWriteLanguage("hi")}
              className={`px-3 py-1 text-xs font-bold rounded-full transition-all cursor-pointer active:scale-95 ${
                writeLanguage === "hi" ? "bg-sky-500 text-slate-950" : "text-sky-300 hover:text-sky-200"
              }`}
            >
              हिन्दी (Hindi)
            </button>
          </div>
        </div>
      </div>

      {/* Search Input Container with sky blue transparent styling */}
      <motion.form
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={onSearchSubmit}
        className="relative z-10 w-full mb-3 shadow-lg rounded-xl bg-sky-950/40 border border-sky-500/30 p-2 backdrop-blur-md"
      >
        <div className="flex items-center space-x-2">
          {/* Voice Search Button */}
          <button
            type="button"
            onClick={startVoiceSearch}
            className={`p-2.5 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
              isListening
                ? "bg-red-950 border border-red-500 text-red-500 animate-pulse"
                : "bg-sky-950/80 hover:bg-sky-900 border border-sky-500/30 text-sky-300"
            }`}
            title="Speak to Search"
          >
            <Mic className={`h-5 w-5 ${isListening ? "text-red-500 fill-red-500" : ""}`} />
          </button>

          {/* Search Bar Input */}
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              isListening 
                ? (writeLanguage === "hi" ? "सुन रहा हूँ... बोलें" : "Listening... Speak now") 
                : (writeLanguage === "hi" ? "लाल किले के बारे में कुछ भी खोजें..." : "Search or chat regarding Red Fort (e.g. History, Architecture, Timings)...")
            }
            className="flex-1 bg-slate-950/90 border-none px-3 py-2 text-slate-100 placeholder-sky-300/60 font-serif text-base focus:outline-none focus:ring-1 focus:ring-sky-500 rounded-lg min-w-0"
          />

          {/* Submit Search Ask Button */}
          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className={`p-2.5 rounded-lg font-serif bg-gradient-to-r from-sky-600 to-sky-800 hover:from-sky-500 hover:to-sky-700 text-slate-100 border border-sky-400/30 transition-all shadow-md flex items-center space-x-1 cursor-pointer ${
              (!inputText.trim() || isLoading) && "opacity-40 cursor-not-allowed"
            }`}
          >
            <Send className="h-4 w-4" />
            <span className="hidden sm:inline font-medium">{writeLanguage === "hi" ? "पूछें" : "Ask"}</span>
          </button>
        </div>

        {/* Dynamic Voice indicators */}
        <div className="flex justify-between items-center px-1 mt-1">
          <p className="text-xs text-sky-400 font-serif italic">
            {isListening ? (
              <span className="text-red-400 font-bold animate-pulse flex items-center space-x-1">
                <span>🎙️</span>
                <span>Speak Now / यहाँ बोलें (Listening...)</span>
              </span>
            ) : (
              "*Ask voice-activated or typed queries focusing ONLY on Red Fort Delhi."
            )}
          </p>
          <SpeechIndicator isActive={isListening} type="mic" />
        </div>
      </motion.form>

      {/* Quick Search Accelerators */}
      {messages.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-2 gap-2 mb-3 max-w-2xl mx-auto w-full"
        >
          {quickSearches.map((query, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleQuery(query)}
              className="px-3 py-2 text-left text-sm font-serif bg-sky-950/30 hover:bg-sky-905/60 transition-all border border-sky-500/20 text-sky-200 hover:text-amber-300 rounded-lg flex items-center space-x-2 shadow-sm cursor-pointer"
            >
              <Compass className="h-4 w-4 text-sky-400 flex-shrink-0" />
              <span className="truncate">{query}</span>
            </button>
          ))}
        </motion.div>
      )}

      {/* Middle Scrollable Section: Search & Chatbot Responses */}
      <div
        id="middle-response-area"
        className="flex-1 overflow-y-auto mb-4 bg-slate-950/85 border border-sky-500/35 rounded-xl p-4 min-h-[200px] max-h-[500px] shadow-2xl flex flex-col backdrop-blur-md"
      >
        <AnimatePresence initial={false}>
          {messages.length === 0 && !isLoading && (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 my-auto text-sky-400/80 font-serif">
              <Compass className="h-10 w-10 text-sky-500/50 mb-2 animate-pulse" />
              <p className="text-lg font-medium text-amber-400 font-bold">Ask Red Fort AI Hub</p>
              <p className="max-w-md text-sm text-sky-300/70 leading-relaxed mt-1">
                Speak or type short questions about Lahori Gate, Diwan-i-Aam, Shah Jahan, and timings. Answers will appear in short sentences.
              </p>
            </div>
          )}

          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex flex-col mb-4 ${msg.role === "user" ? "items-end" : "items-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-lg p-3 shadow-md border ${
                  msg.role === "user"
                    ? "bg-sky-900/40 border-sky-400/40 text-sky-50"
                    : "bg-sky-950/70 border-sky-500/20 text-slate-100"
                }`}
              >
                {/* Message Header */}
                <div className="flex items-center justify-between border-b border-sky-900 pb-1.5 mb-1.5 text-[11px] text-sky-300 font-serif font-semibold tracking-wider">
                  <span className={msg.role === "user" ? "text-sky-300" : "text-amber-400"}>
                    {msg.role === "user" ? "Visitor Query" : "Red Fort AI Chronicler"}
                  </span>
                  <span>{msg.timestamp}</span>
                </div>

                {/* Message Text Content */}
                <p className="font-serif text-base leading-relaxed whitespace-pre-line text-slate-100">
                  {msg.text}
                </p>

                {/* Direct clean playback and speaking indicators (Remove verbose double listen options) */}
                {msg.role === "bot" && (
                  <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-sky-900/60 text-xs">
                    <span className="text-[11px] text-sky-400 font-serif flex items-center space-x-1">
                      <span>📢</span>
                      <span>
                        {speakingMsgId === `${msg.id}-${writeLanguage}` 
                          ? "Scribe narrating aloud..." 
                          : "Narrator ready"}
                      </span>
                    </span>
                    
                    {speakingMsgId === `${msg.id}-${writeLanguage}` ? (
                      <button
                        type="button"
                        onClick={() => {
                          if (synthRef.current) {
                            synthRef.current.cancel();
                            setSpeakingMsgId(null);
                          }
                        }}
                        className="text-[11px] font-bold px-2.5 py-1 bg-red-950/90 text-red-400 border border-red-500/30 rounded cursor-pointer hover:bg-red-900 transition-all flex items-center space-x-1 animate-pulse"
                      >
                        <VolumeX className="h-3 w-3" />
                        <span>Stop Voice</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => speakText(msg.id, msg.text, writeLanguage)}
                        className="text-[11px] font-bold px-2.5 py-1 bg-sky-900/60 hover:bg-sky-850 text-sky-200 border border-sky-500/30 rounded cursor-pointer transition-all flex items-center space-x-1"
                      >
                        <Volume2 className="h-3 w-3" />
                        <span>Replay</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center space-x-2 p-3 bg-sky-950/20 rounded-lg w-fit border border-sky-500/20"
            >
              <RefreshCw className="h-4 w-4 text-sky-400 animate-spin" />
              <span className="text-xs text-sky-300 font-serif font-medium">Scribing answers about Lal Qila...</span>
            </motion.div>
          )}

          {errMessage && (
            <div className="bg-red-950/60 border border-red-500/40 text-red-200 text-sm p-3 rounded-lg font-serif">
              {errMessage}
            </div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

    </div>
  );
}
