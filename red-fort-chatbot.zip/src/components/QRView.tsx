import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { QrCode, Download, Trash2, Plus, Image, Eye, EyeOff, Radio, AlertCircle, RefreshCw } from "lucide-react";
import { QRItem } from "../types";
import QRCode from "qrcode";

interface QRViewProps {
  onPreviewQR: (item: QRItem) => void;
}

export default function QRView({ onPreviewQR }: QRViewProps) {
  const [qrsList, setQrsList] = useState<QRItem[]>([]);
  const [isLoadingList, setIsLoadingList] = useState(false);

  // Form states
  const [title, setTitle] = useState("");
  const [infoText, setInfoText] = useState("");
  const [base64Img, setBase64Img] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorText, setErrorText] = useState("");

  // Generated QR preview state
  const [generatedQRUrl, setGeneratedQRUrl] = useState("");
  const [newlyCreatedId, setNewlyCreatedId] = useState("");

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load Saved QR codes from backend
  const fetchQRList = async () => {
    setIsLoadingList(true);
    try {
      const res = await fetch("/api/qrs");
      if (res.ok) {
        const result = await res.json();
        setQrsList(result.list || []);
      }
    } catch (err) {
      console.error("Failed to load QR list:", err);
    } finally {
      setIsLoadingList(false);
    }
  };

  useEffect(() => {
    fetchQRList();
  }, []);

  // Handle image file selection and conversion to base64
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      alert("Image is too large. Please select an image smaller than 8MB.");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setBase64Img(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Submit and Create QR
  const handleCreateQR = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!infoText.trim()) {
      setErrorText("Information text is required to embed inside of the QR page.");
      return;
    }

    setIsSubmitting(true);
    setErrorText("");

    try {
      const res = await fetch("/api/qr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim() || undefined,
          text: infoText,
          image: base64Img || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to create QR code.");
      }

      setNewlyCreatedId(data.id);

      // Generate actual offline QR code image targeting the view URL
      const shareUrl = `${window.location.origin}?qrId=${data.id}`;
      const qrDataUrl = await QRCode.toDataURL(shareUrl, {
        width: 320,
        margin: 2,
        color: {
          dark: "#02111f", // Elegant deep sky shadow value
          light: "#ffffff",
        },
      });

      setGeneratedQRUrl(qrDataUrl);

      // Reset form variables
      setTitle("");
      setInfoText("");
      setBase64Img("");
      if (fileInputRef.current) fileInputRef.current.value = "";

      // Reload list
      await fetchQRList();
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || "An error occurred while creating the QR.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Delete QR entry with safety checks
  const handleDeleteQR = async (id: string) => {
    if (id.startsWith("static-")) {
      alert("This is a master-seeded historical Red Fort guide and cannot be deleted.");
      return;
    }

    if (!confirm("Are you sure you want to delete this QR code and its uploaded information?")) return;

    try {
      const res = await fetch(`/api/qr/${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        setQrsList((prev) => prev.filter((item) => item.id !== id));
        if (newlyCreatedId === id) {
          setGeneratedQRUrl("");
          setNewlyCreatedId("");
        }
      } else {
        alert("Failed to delete QR from the server database.");
      }
    } catch (err) {
      console.error(err);
      alert("Error contacting the server to delete QR.");
    }
  };

  // Download Generated QR code as PNG file
  const handleDownloadQR = async (qrId: string, itemTitle: string) => {
    try {
      const shareUrl = `${window.location.origin}?qrId=${qrId}`;
      const downloadDataUrl = await QRCode.toDataURL(shareUrl, {
        width: 600,
        margin: 2,
      });

      const link = document.createElement("a");
      link.href = downloadDataUrl;
      const cleanFileName = (itemTitle || "red-fort-qr").toLowerCase().replace(/[^a-z0-9]/g, "-");
      link.download = `red-fort-qr-${cleanFileName}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Download failed:", err);
    }
  };

  return (
    <div id="qr-container" className="flex flex-col lg:flex-row flex-1 w-full gap-6 px-4 py-3 max-w-6xl mx-auto h-full">
      
      {/* LEFT COLUMN: Create QR Form & Latest Created QR */}
      <motion.div
        initial={{ opacity: 0, x: -15 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex-1 flex flex-col space-y-4"
      >
        <div className="bg-sky-950/40 border border-sky-500/30 p-5 rounded-2xl shadow-xl backdrop-blur-md">
          <div className="flex items-center space-x-2.5 mb-4 border-b border-sky-900/40 pb-3">
            <Plus className="h-5 w-5 text-amber-400" />
            <h2 className="text-xl font-serif text-amber-400 font-bold tracking-wide">
              Create New QR Guide
            </h2>
          </div>

          <form onSubmit={handleCreateQR} className="space-y-4 font-serif">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-sky-300 mb-1">
                Pinpoint Title / Topic Name
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Diwan-i-Aam (Hall of Public Audience)"
                className="w-full bg-slate-950/90 border border-sky-500/10 hover:border-sky-500/40 font-serif text-slate-100 placeholder-sky-300/60 focus:outline-none focus:ring-1 focus:ring-sky-500 px-3 py-2 rounded-lg"
              />
            </div>

            {/* Information upload text */}
            <div>
              <label className="block text-sm font-medium text-sky-300 mb-1">
                Upload Information Description *
              </label>
              <textarea
                value={infoText}
                onChange={(e) => setInfoText(e.target.value)}
                rows={4}
                required
                placeholder="Paste or write detailed guides, histories, facts, or instructions for this QR code location. Visitors scanning this will read this exact information or listen to it read out loud."
                className="w-full bg-slate-950/90 border border-sky-500/10 hover:border-sky-500/40 font-serif text-slate-100 placeholder-sky-300/60 focus:outline-none focus:ring-1 focus:ring-sky-500 px-3 py-2 rounded-lg"
              />
            </div>

            {/* Upload Image block */}
            <div>
              <label className="block text-sm font-medium text-sky-300 mb-1 flex items-center justify-between">
                <span>Upload Companion Image</span>
                <span className="text-xs text-sky-400 italic">Optional (Max 8MB)</span>
              </label>
              
              <div className="flex items-center space-x-4">
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleImageChange}
                  className="hidden"
                />
                
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 bg-slate-950/90 hover:bg-slate-900 border border-sky-500/20 text-sky-300 rounded-lg text-sm transition-all flex items-center space-x-2 hover:border-sky-500/40 cursor-pointer"
                >
                  <Image className="h-4 w-4 text-amber-400" />
                  <span>Choose Image</span>
                </button>

                {base64Img && (
                  <button
                    type="button"
                    onClick={() => setBase64Img("")}
                    className="text-xs text-red-400 hover:underline cursor-pointer"
                  >
                    Remove Image
                  </button>
                )}
              </div>

              {/* Preview image block */}
              {base64Img && (
                <div className="mt-2.5 relative w-full h-[120px] rounded-lg overflow-hidden border border-sky-500/20 animate-fade-in">
                  <img
                    src={base64Img}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>

            {errorText && (
              <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-lg text-sm text-red-200 flex items-center space-x-2">
                <AlertCircle className="h-4 w-4" />
                <span>{errorText}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full py-2.5 font-serif font-bold text-center bg-gradient-to-r from-amber-500 to-amber-700 hover:from-amber-400 hover:to-amber-600 border border-amber-400/20 text-slate-950 rounded-lg transition-all shadow-md cursor-pointer ${
                isSubmitting && "opacity-50 cursor-not-allowed"
              }`}
            >
              {isSubmitting ? "Uploading & Generating QR..." : "Generate QR Code"}
            </button>
          </form>
        </div>

        {/* CURRENTLY ENCODED QR BLOCK */}
        <AnimatePresence>
          {generatedQRUrl && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="bg-sky-950/40 border border-amber-500/30 p-5 rounded-2xl flex flex-col items-center justify-center text-center shadow-xl backdrop-blur-md"
            >
              <h3 className="text-base text-amber-400 font-bold mb-1 tracking-wide uppercase">
                Generated & Enrolled Correctly
              </h3>
              <p className="text-sky-200 text-xs mb-3 font-serif">
                Anyone scanning this QR code has immediate access to your description and image!
              </p>

              {/* QR Block container */}
              <div className="p-3 bg-white rounded-xl shadow-lg border border-slate-200">
                <img
                  src={generatedQRUrl}
                  alt="Generated Qrcode"
                  className="w-[180px] h-[180px] object-contain"
                />
              </div>

              {/* Download or Preview triggers */}
              <div className="flex space-x-3 mt-4 w-full">
                <button
                  type="button"
                  onClick={() => handleDownloadQR(newlyCreatedId, "Lal Qila Spot")}
                  className="flex-1 py-1.5 text-xs bg-slate-950/90 hover:bg-slate-900 text-sky-300 font-semibold border border-sky-500/30 rounded-lg transition-all flex items-center justify-center space-x-1 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5 text-amber-400" />
                  <span>Download QR</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const found = qrsList.find((x) => x.id === newlyCreatedId);
                    if (found) onPreviewQR(found);
                  }}
                  className="flex-1 py-1.5 text-xs bg-sky-900 hover:bg-sky-850 text-white font-semibold border border-sky-500/20 rounded-lg transition-all flex items-center justify-center space-x-1 cursor-pointer"
                >
                  <Eye className="h-3.5 w-3.5" />
                  <span>Scan Preview</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* RIGHT COLUMN: Saved QR codes list */}
      <motion.div
        initial={{ opacity: 0, x: 15 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex-1 flex flex-col space-y-4"
      >
        <div className="bg-sky-950/40 border border-sky-500/30 p-5 rounded-2xl shadow-xl flex-1 flex flex-col backdrop-blur-md animate-fade-in">
          <div className="flex items-center justify-between mb-4 border-b border-sky-900/40 pb-3">
            <div className="flex items-center space-x-2.5">
              <QrCode className="h-5 w-5 text-sky-400" />
              <h2 className="text-xl font-serif text-sky-300 font-bold tracking-wide">
                Active Enrolled QR Cards ({qrsList.length})
              </h2>
            </div>
            <button
              onClick={fetchQRList}
              className="p-1 px-2.5 bg-slate-950 border border-sky-500/15 hover:border-sky-500/45 rounded text-xs text-sky-400 flex items-center space-x-1 hover:text-sky-200 cursor-pointer"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Sync</span>
            </button>
          </div>

          {/* Stored Enrolled QRs Grid */}
          <div className="flex-1 overflow-y-auto max-h-[500px] space-y-3 pr-1">
            {isLoadingList ? (
              <div className="flex flex-col items-center justify-center h-48 space-y-2 text-slate-400">
                <RefreshCw className="h-6 w-6 animate-spin text-sky-500" />
                <span className="font-serif text-sm text-sky-300">Syncing with Lal Qila log ledger...</span>
              </div>
            ) : qrsList.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center p-8 text-sky-400/80 h-48 border border-dashed border-sky-500/20 rounded-xl">
                <QrCode className="h-10 w-10 text-sky-500/40 mb-2" />
                <p className="font-serif text-base text-sky-300">No active QR Guides generated yet</p>
                <p className="text-xs text-slate-500 mt-1 max-w-sm leading-relaxed">
                  Provide description details, submit, and download your companion QR code vectors.
                </p>
              </div>
            ) : (
              qrsList.map((qr) => (
                <motion.div
                  key={qr.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={`border p-3 rounded-xl flex items-center justify-between transition-all ${
                    qr.id.startsWith("static-") 
                      ? "bg-amber-950/20 border-amber-500/30" 
                      : "bg-slate-950/90 border-sky-500/10 hover:border-sky-500/30"
                  }`}
                >
                  <div className="flex items-center space-x-3 min-w-0 flex-1">
                    <div className="p-2 bg-sky-950/80 border border-sky-400/20 rounded-lg flex-shrink-0">
                      <QrCode className={`h-5 w-5 ${qr.id.startsWith("static-") ? "text-amber-400 animate-pulse" : "text-sky-400"}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4 className="text-base text-sky-100 font-serif font-bold truncate flex items-center gap-1.5">
                        <span>{qr.title || "Untitled Spot Info"}</span>
                        {qr.id.startsWith("static-") && (
                          <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold px-1.5 py-0.5 rounded uppercase tracking-widest leading-none">
                            Primary
                          </span>
                        )}
                      </h4>
                      <p className="text-xs text-slate-300/80 italic truncate font-serif">
                        {qr.text}
                      </p>
                    </div>
                  </div>

                  {/* Actions Area */}
                  <div className="flex items-center space-x-2 ml-3">
                    <button
                      type="button"
                      onClick={() => onPreviewQR(qr)}
                      className="p-1.5 bg-slate-900 border border-sky-500/20 text-sky-300 rounded hover:bg-sky-900/40 hover:text-white transition-all cursor-pointer"
                      title="Preview Scanned Page"
                    >
                      <Eye className="h-4 w-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDownloadQR(qr.id, qr.title)}
                      className="p-1.5 bg-slate-900 border border-sky-500/20 text-sky-300 rounded hover:bg-sky-900/40 hover:text-white transition-all cursor-pointer"
                      title="Download QR PNG"
                    >
                      <Download className="h-4 w-4" />
                    </button>

                    {/* Delete only allowed for user custom guides! */}
                    {!qr.id.startsWith("static-") ? (
                      <button
                        type="button"
                        onClick={() => handleDeleteQR(qr.id)}
                        className="p-1.5 bg-slate-900 border border-red-500/20 text-red-400 rounded hover:bg-red-950/40 hover:text-red-300 transition-all cursor-pointer"
                        title="Delete QR"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    ) : (
                      <div className="p-1.5 bg-sky-950/30 border border-sky-500/10 text-sky-400/30 rounded cursor-not-allowed" title="Primary system guide">
                        <Trash2 className="h-4 w-4 opacity-30" />
                      </div>
                    )}
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
