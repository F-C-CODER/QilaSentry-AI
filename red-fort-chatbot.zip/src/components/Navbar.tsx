import React from "react";
import { Compass, LogOut, Sparkles } from "lucide-react";

interface NavbarProps {
  currentTab: "home" | "exit";
  onTabChange: (tab: "home" | "exit") => void;
}

export default function Navbar({ currentTab, onTabChange }: NavbarProps) {
  return (
    <nav className="w-full bg-slate-950/70 border-b border-sky-500/30 shadow-lg backdrop-blur-md sticky top-0 z-50 print:hidden">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          
          {/* Identity Branding - Fully Responsive & Mobile-safe */}
          <div className="flex items-center space-x-1.5 min-w-0">
            <div className="p-1 sm:p-1.5 bg-sky-950/80 border border-sky-500/40 rounded-lg shadow-inner flex-shrink-0">
              <Sparkles className="h-4 w-4 sm:h-5 sm:w-5 text-amber-400 animate-pulse" />
            </div>
            <span className="text-base sm:text-lg md:text-xl font-serif font-bold text-amber-400 tracking-wider whitespace-nowrap truncate">
              Red Fort AI Hub
            </span>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center space-x-1 sm:space-x-3">
            
            {/* HOME Tab (Chatbot) */}
            <button
              onClick={() => onTabChange("home")}
              className={`px-2.5 py-1.5 rounded-lg font-serif text-xs sm:text-sm md:text-base font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                currentTab === "home"
                  ? "bg-sky-900/60 border border-sky-400/50 text-amber-300 shadow-md"
                  : "text-sky-300 hover:text-amber-300 hover:bg-sky-950/40"
              }`}
            >
              <Compass className="h-4 w-4 text-sky-400" />
              <span>Home</span>
            </button>

            {/* EXIT Tab */}
            <button
              onClick={() => onTabChange("exit")}
              className={`px-2.5 py-1.5 rounded-lg font-serif text-xs sm:text-sm md:text-base font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                currentTab === "exit"
                  ? "bg-sky-950 border border-red-500/40 text-red-400 shadow-inner"
                  : "text-slate-400 hover:text-red-400 hover:bg-red-950/20"
              }`}
            >
              <LogOut className="h-4 w-4 text-red-400" />
              <span>Exit</span>
            </button>

          </div>
        </div>
      </div>
    </nav>
  );
}
