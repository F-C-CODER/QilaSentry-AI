import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Volume2, VolumeX, Compass, Calendar, Sparkles, CornerDownLeft } from "lucide-react";
import { QRItem } from "../types";
import SpeechIndicator from "./SpeechIndicator";

interface ScannedQRViewProps {
  qrId: string;
  onClose: () => void;
}

export default function ScannedQRView({ qrId, onClose }: ScannedQRViewProps) {
  const [item, setItem] = useState<QRItem | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorStr, setErrorStr] = useState("");

  const [speakingLanguage, setSpeakingLanguage] = useState<"en" | "hi" | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Load Scan Details by API
  useEffect(() => {
    const fetchQRDetails = async () => {
      setIsLoading(true);
      setErrorStr("");
      try {
        const res = await fetch(`/api/qr/${qrId}`);
        const data = await res.json();
        if (res.ok && data.success) {
          setItem(data.item);
        } else {
          setErrorStr(data.error || "The requested QR information was not found or was deleted.");
        }
      } catch (err) {
        console.error(err);
        setErrorStr("Failed to connect to the Lal Qila server registry.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchQRDetails();

    if (typeof window !== "undefined") {
      synthRef.current = window.speechSynthesis;
    }

    return () => {
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, [qrId]);

  // Read Text narrative Aloud using Speech Synthesis with low pace and Indian focus
  const handleReadAloud = (speakLang: "en" | "hi") => {
    if (!synthRef.current || !item) return;

    if (speakingLanguage === speakLang) {
      synthRef.current.cancel();
      setSpeakingLanguage(null);
      return;
    }

    // Cancel any previous speech
    synthRef.current.cancel();

    // Clean up markdown style if present
    const cleanText = `${item.title}. ${item.text.replace(/[*#_`~]/g, "")}`;
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utteranceRef.current = utterance;

    // Slow and low-tempo pace as requested
    utterance.rate = 0.76;

    const voices = synthRef.current.getVoices();
    if (speakLang === "hi") {
      utterance.lang = "hi-IN";
      const hindiVoice = voices.find((v) => v.lang.includes("hi-IN") || v.lang.includes("hi"));
      if (hindiVoice) {
        utterance.voice = hindiVoice;
      }
    } else {
      utterance.lang = "en-IN";
      // Fetch English with Indian pronunciation accent or fallback
      const indianVoice = voices.find((v) => v.lang.includes("en-IN") || v.lang.includes("en-GB"));
      if (indianVoice) {
        utterance.voice = indianVoice;
      }
    }

    utterance.onend = () => {
      setSpeakingLanguage(null);
    };

    utterance.onerror = () => {
      setSpeakingLanguage(null);
    };

    setSpeakingLanguage(speakLang);
    synthRef.current.speak(utterance);
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center min-h-[300px] text-sky-300 font-serif">
        <div className="animate-spin h-8 w-8 border-4 border-sky-400 border-t-transparent rounded-full mb-3" />
        <span className="text-lg text-sky-200">Enrolling QR Slices...</span>
        <span className="text-xs text-sky-400 mt-1">Retrieving details from Lal Qila chronicle registry</span>
      </div>
    );
  }

  if (errorStr) {
    return (
      <div className="max-w-xl mx-auto px-4 py-8 text-center font-serif">
        <div className="bg-red-950/60 border border-red-500/40 p-6 rounded-2xl shadow-xl backdrop-blur-md">
          <p className="text-xl font-bold text-red-400 mb-2">QR Code Search Error</p>
          <p className="text-slate-300 mb-6 text-base leading-relaxed">{errorStr}</p>
          <button
            onClick={onClose}
            className="px-5 py-2 font-serif font-semibold bg-sky-900 hover:bg-sky-850 text-white rounded-lg border border-sky-500/20 transition-all flex items-center space-x-2 mx-auto shadow cursor-pointer"
          >
            <Compass className="h-4 w-4" />
            <span>Go to Scribe Chatbot</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto px-4 py-4"
    >
      <div className="bg-sky-950/40 border border-sky-500/30 rounded-2xl overflow-hidden shadow-2xl relative backdrop-blur-md">
        
        {/* Decorative Royal copper gold line */}
        <div className="h-1 bg-gradient-to-r from-amber-600 via-sky-400 to-amber-600" />

        {/* Hero image header if provided */}
        {item?.image ? (
          <div className="h-[240px] w-full relative overflow-hidden border-b border-sky-500/20">
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
          </div>
        ) : (
          <div className="py-6 bg-gradient-to-b from-sky-950/50 to-slate-950/80 text-center border-b border-sky-500/20">
            <Sparkles className="h-10 w-10 text-amber-550 mx-auto mb-2 animate-pulse" />
            <span className="text-[11px] text-amber-400 font-bold tracking-widest uppercase font-serif">
              Mughal Chronicle Log Entry
            </span>
          </div>
        )}

        {/* Content area */}
        <div className="p-6 font-serif">
          {/* Metadata */}
          <div className="flex flex-wrap items-center justify-between text-xs text-sky-300/80 gap-2 mb-3 border-b border-sky-900 pb-3">
            <div className="flex items-center space-x-1">
              <Calendar className="h-3.5 w-3.5 text-sky-400" />
              <span>
                Archived: {new Date(item?.createdAt || "").toLocaleString()}
              </span>
            </div>
            <span className="px-2 py-0.5 bg-sky-950/80 text-sky-300 border border-sky-500/25 rounded-full uppercase tracking-wider text-[10px]">
              ID: {qrId}
            </span>
          </div>

          {/* Title */}
          <h1 className="text-2xl md:text-3xl font-serif font-bold text-amber-400 tracking-wide mb-4">
            {item?.title || "Lal Qila Spot Artifact"}
          </h1>

          {/* Dual Bilingual Audio Narrations with low pace */}
          <div className="bg-slate-950/95 p-3 rounded-xl border border-sky-500/20 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => handleReadAloud("en")}
                className={`px-4 py-2 font-serif font-bold rounded-lg transition-all text-xs flex items-center space-x-2 border shadow cursor-pointer ${
                  speakingLanguage === "en"
                    ? "bg-red-950 border-red-500 text-red-400 scale-[1.02]"
                    : "bg-sky-900 border-sky-500/30 text-sky-100 hover:bg-sky-850"
                }`}
                title="Low Pace English Indian accent"
              >
                <Volume2 className="h-4 w-4" />
                <span>{speakingLanguage === "en" ? "Stop English Scribe" : "Listen (English Accent)"}</span>
              </button>

              <button
                onClick={() => handleReadAloud("hi")}
                className={`px-4 py-2 font-serif font-bold rounded-lg transition-all text-xs flex items-center space-x-2 border shadow cursor-pointer ${
                  speakingLanguage === "hi"
                    ? "bg-red-950 border-red-500 text-red-400 scale-[1.02]"
                    : "bg-sky-900 border-sky-500/30 text-sky-100 hover:bg-sky-850"
                }`}
                title="Low Pace Hindi voice narration"
              >
                <Volume2 className="h-4 w-4" />
                <span>{speakingLanguage === "hi" ? "नैरेशन रोकें (Stop Hindi)" : "हिन्दी में सुनें (Listen Hindi)"}</span>
              </button>
            </div>

            <SpeechIndicator isActive={speakingLanguage !== null} type="tts" />
          </div>

          {/* Text Description Details */}
          <div className="font-serif text-slate-100 text-lg leading-relaxed whitespace-pre-line bg-slate-950/90 p-5 rounded-xl border border-sky-500/20 shadow-inner">
            {item?.text}
          </div>

          {/* Scribe portal redirection */}
          <div className="mt-8 flex justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2.5 font-serif font-bold text-sm text-slate-900 bg-gradient-to-r from-sky-400 to-sky-600 hover:from-sky-300 hover:to-sky-500 border border-sky-450/20 rounded-lg transition-all flex items-center space-x-1.5 shadow cursor-pointer"
            >
              <CornerDownLeft className="h-4 w-4" />
              <span>Back to Hub Scribe</span>
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
