import React from "react";
import { motion } from "motion/react";

interface SpeechIndicatorProps {
  isActive: boolean;
  type: "tts" | "mic";
}

export default function SpeechIndicator({ isActive, type }: SpeechIndicatorProps) {
  if (!isActive) return null;

  return (
    <div className="flex items-center space-x-1.5 px-3 py-1 bg-blue-900/40 border border-blue-500/30 rounded-full">
      <span className="text-xs text-blue-300 font-serif tracking-wider uppercase animate-pulse">
        {type === "tts" ? "Speaking..." : "Listening..."}
      </span>
      <div className="flex space-x-1 items-end h-3">
        {[...Array(4)].map((_, i) => (
          <motion.div
            key={i}
            className={`w-0.5 rounded-full ${type === "tts" ? "bg-amber-400" : "bg-red-400"}`}
            animate={{
              height: isActive ? [4, 12, 4] : 4,
            }}
            transition={{
              duration: 0.6 + i * 0.15,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>
    </div>
  );
}
